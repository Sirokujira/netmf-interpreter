﻿' How to execute
' - Copy the follwing bitmap files on root directory of SD card.
'   MIF201201l.bmp
'   MIF201202l.bmp
'   MIF201203l.bmp
'   MIF201204l.bmp
'   MIF201205l.bmp
'   MIF201206l.bmp
'   MIF201207l.bmp

#Const CQ_FRK_FM3 = True
'#Const CQ_FRK_RX62N = True
'#Const CQ_FRK_NXP_ARM = True

Imports System
Imports System.IO
Imports System.Threading
Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports Microsoft.SPOT.Hardware.SPI
Imports CQ.NETMF.LCD
Imports CQ.NETMF.SD

Namespace SampleSDBitmap

    Public Class Program
#If CQ_FRK_FM3 Then
        Private Shared [mod] As SPI.SPI_module = SPI.SPI_module.SPI1    ' SPI ch0 = SPI1
        Private Shared pinSDCS As Cpu.Pin = DirectCast(&H30, Cpu.Pin)   ' SPI CS = P30
#End If
#If CQ_FRK_RX62N Then
        Private Shared [mod] As SPI.SPI_module = SPI.SPI_module.SPI1    ' SPI ch0 = SPI1
        Private Shared pinSDCS As Cpu.Pin = DirectCast(100, Cpu.Pin)    ' SPI CS = PC4 = 8*0xc + 4 = 100
#End If
#If CQ_FRK_NXP_ARM Then
        Private Shared [mod] As SPI.SPI_module = SPI.SPI_module.SPI1    ' SPI ch0 = SPI1
        Private Shared pinSDCS As Cpu.Pin = DirectCast(&H06, Cpu.Pin)   ' SPI CS = P0[6]
#End If
        Private Shared bitmapDy As UInteger = 1
        Private Shared headerSize As Integer = &H36

        Public Sub BmpRead16(ByVal inputFileName As String)
            Dim ofs As Integer = 0
            Dim inputFile As New FileStream(inputFileName, FileMode.Open)
            Dim bitmapHeader As Byte() = New Byte(Program.headerSize - 1) {}
            ofs = (ofs + inputFile.Read(bitmapHeader, 0, Program.headerSize))
            Dim wx As UInteger = CUInt(Utility.ExtractValueFromArray(bitmapHeader, &H12, 4))
            Dim wy As UInteger = CUInt(Utility.ExtractValueFromArray(bitmapHeader, &H16, 4))
            Dim depth As UInteger = CUInt(Utility.ExtractValueFromArray(bitmapHeader, &H1C, 2))
            'Dim lineBytes As UInteger = wx * (depth / 8)
            Dim lineBytes As UInteger = wx * 2
            Dim bufSize As UInteger = (lineBytes * Program.bitmapDy)
            Dim bitmapOneLine As Byte() = New Byte(bufSize - 1) {}
            Dim y As Integer = ((wy - 1) - Program.bitmapDy)
            Do While (y >= 0)
                inputFile.Read(bitmapOneLine, 0, bufSize)
                LCDDevice.BitBltEx(0, CUInt(y), CUInt(wx), CUInt(Program.bitmapDy), bitmapOneLine)
                Thread.Sleep(10)
                y = (y - Program.bitmapDy)
            Loop
            inputFile.Close()
        End Sub

        Public Shared Sub Main()
            Debug.Print("Mounting SD...")
            StorageDevice.MountSD("SD", Program.mod, Program.pinSDCS)
            LCDDevice.Clear()
            Dim p As New Program
            Do While True
                Dim i As Integer = 1
                Do While (i <= 7)
                    p.BmpRead16(("\SD\MIF20120" & i.ToString & "l.bmp"))
                    Thread.Sleep(&H7D0)
                    i += 1
                Loop
            Loop
        End Sub
    End Class

End Namespace