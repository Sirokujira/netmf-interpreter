﻿#Const CQ_FRK_FM3 = True
'#Const CQ_FRK_RX62N = True
'#Const CQ_FRK_NXP_ARM = True

Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports System
Imports System.Threading

Namespace SampleAD
    Public Class Program
#If CQ_FRK_FM3 Then
        Private Shared acThermal As Cpu.AnalogChannel = DirectCast(17, Cpu.AnalogChannel)
        Private Shared acVR2 As Cpu.AnalogChannel = DirectCast(16, Cpu.AnalogChannel)
        Private Shared LEDpin As Cpu.Pin = DirectCast(&HF3, Cpu.Pin)
#End If
#If CQ_FRK_RX62N Then
        Private Shared acThermal As Cpu.AnalogChannel = Cpu.AnalogChannel.ANALOG_1
        Private Shared acVR2 As Cpu.AnalogChannel = Cpu.AnalogChannel.ANALOG_0
        Private Shared LEDpin As Cpu.Pin = DirectCast(&H0D, Cpu.Pin)
#End If
#If CQ_FRK_NXP_ARM Then
        Private Shared acThermal As Cpu.AnalogChannel = Cpu.AnalogChannel.ANALOG_1
        Private Shared acVR2 As Cpu.AnalogChannel = Cpu.AnalogChannel.ANALOG_0
        Private Shared LEDpin As Cpu.Pin = DirectCast(&H32, Cpu.Pin)
#End If
        ' Methods
        Public Shared Sub Main()
            Dim LED As New OutputPort(Program.LEDpin, False)
            Dim aiVR2 As New AnalogInput(Program.acVR2)
            Dim aiThermal As New AnalogInput(Program.acThermal)
            Dim i As Integer = 0
            Do While True
                Debug.Print(String.Concat(New String() {i.ToString, " times Slide Resistor = ", aiVR2.ReadRaw.ToString, " Thermal Sensor = ", aiThermal.ReadRaw.ToString}))
                LED.Write(False)
                Thread.Sleep(500)
                LED.Write(True)
                Thread.Sleep(500)
                i += 1
            Loop
        End Sub
    End Class
End Namespace