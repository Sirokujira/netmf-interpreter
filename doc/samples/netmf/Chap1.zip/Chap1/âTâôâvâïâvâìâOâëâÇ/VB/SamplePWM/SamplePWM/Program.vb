﻿#Const CQ_FRK_FM3 = True
'#Const CQ_FRK_RX62N = True
'#Const CQ_FRK_NXP_ARM = True

Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports System
Imports System.Threading

Namespace SamplePWM
    Public Class Program
#If CQ_FRK_FM3 Then
        Private Shared ch As Cpu.PWMChannel = Cpu.PWMChannel.PWM_6  ' LED PF3 -> channel 6
#End If
#If CQ_FRK_RX62N Then
        Private Shared ch As Cpu.PWMChannel = Cpu.PWMChannel.PWM_0  ' LED P15 -> channel 0
#End If
#If CQ_FRK_NXP_ARM Then
        Private Shared ch As Cpu.PWMChannel = Cpu.PWMChannel.PWM_0  ' LED P1[18] -> channel 0
#End If
        Private Shared frequency As Double = 100.0
        Private Shared pwm0 As PWM = New PWM(Program.ch, Program.frequency, 0, False)

        Public Shared Sub pwm0Thread()
            Dim duration As Double = 0
            Dim delta As Double = 0.025
            Program.pwm0.Start()
            Do While True
                Thread.Sleep(80)
                Program.pwm0.DutyCycle = duration
                duration = (duration + delta)
                If (duration >= 1) Then
                    delta = -0.025
                    duration = 0.975
                End If
                If (duration <= 0) Then
                    delta = 0.025
                    duration = 0.025
                End If
            Loop
        End Sub

        Public Shared Sub Main()
            Dim thread0 As New Thread(AddressOf pwm0Thread)
            thread0.Start()
            Dim i As Integer = 0
            Do While True
                Debug.Print(("Hello, World! " & i.ToString & " times"))
                Thread.Sleep(&H3E8)
                i += 1
            Loop
        End Sub
    End Class
End Namespace