﻿#Const CQ_FRK_FM3 = True
'#Const CQ_FRK_RX62N = True
'#Const CQ_FRK_NXP_ARM = True

Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports System
Imports System.IO.Ports

Namespace SampleSerial

    Public Class Program

        Private Shared LEDPort As OutputPort
        Private Shared PortName As String = "COM1"
#If CQ_FRK_FM3 Then
        Private Shared pinLED As Cpu.Pin = DirectCast(&HF3, Cpu.Pin)
#End If
#If CQ_FRK_RX62N Then
        Private Shared pinLED As Cpu.Pin = DirectCast(&HD, Cpu.Pin)
#End If
#If CQ_FRK_NXP_ARM Then
        Private Shared pinLED As Cpu.Pin = DirectCast(50, Cpu.Pin)
#End If

        Public Shared Sub Main()
            Debug.Print("SampleSerial")
            Debug.Print("Please connect device COM1 to Host and press 1 and 0 keys?")
            Debug.Print("1: LED ON")
            Debug.Print("0: LED OFF")
            Program.LEDPort = New OutputPort(Program.pinLED, False)
            Dim comx As New SerialPort(Program.PortName, &H1C200, Parity.None, 8, StopBits.One)
            AddHandler comx.DataReceived, New SerialDataReceivedEventHandler(AddressOf Program.Serial_DataReceived)
            comx.Open()
            Do While True
            Loop
        End Sub

        Private Shared Sub Serial_DataReceived(ByVal sender As Object, ByVal e As SerialDataReceivedEventArgs)
            Dim comx As SerialPort = DirectCast(sender, SerialPort)
            Dim key As Byte() = New Byte(1 - 1) {}
            Dim len As Integer = comx.Read(key, 0, key.Length)
            If (key(0) = &H31) Then
                Program.LEDPort.Write(False)
            ElseIf (key(0) = &H30) Then
                Program.LEDPort.Write(True)
            End If
            comx.Write(key, 0, key.Length)
        End Sub

    End Class

End Namespace