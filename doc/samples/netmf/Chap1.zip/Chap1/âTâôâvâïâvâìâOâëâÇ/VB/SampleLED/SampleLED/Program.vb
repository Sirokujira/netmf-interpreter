﻿#Const CQ_FRK_FM3 = True
'#Const CQ_FRK_RX62N = True
'#Const CQ_FRK_NXP_ARM = True

Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports System
Imports System.Threading

Namespace SampleLED
    Public Class Program
        ' Methods
#If CQ_FRK_FM3 Then
        Private Shared pinLED As Cpu.Pin = DirectCast(&HF3, Cpu.Pin)
#End If
#If CQ_FRK_RX62N Then
        Private Shared pinLED As Cpu.Pin = DirectCast(&HD, Cpu.Pin)
#End If
#If CQ_FRK_NXP_ARM Then
        Private Shared pinLED As Cpu.Pin = DirectCast(50, Cpu.Pin)
#End If
        Public Shared Sub Main()
            Dim GPIO_Out As New OutputPort(Program.pinLED, True)
            Dim i As Integer = 0
            Do While True
                Debug.Print(("Hello, World! " & i.ToString & " times"))
                GPIO_Out.Write(False)
                Thread.Sleep(500)
                GPIO_Out.Write(True)
                Thread.Sleep(500)
                i += 1
            Loop
        End Sub
    End Class
End Namespace
