﻿#Const CQ_FRK_FM3 = True
'#Const CQ_FRK_RX62N = True
'#Const CQ_FRK_NXP_ARM = True

Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports CQ.NETMF.SD
Imports System
Imports System.IO

Namespace SampleSD
    Public Class Program
#If CQ_FRK_FM3 Then
        Private Shared [mod] As SPI.SPI_module = SPI.SPI_module.SPI1    ' SPI ch0 = SPI1
        Private Shared pinSDCS As Cpu.Pin = DirectCast(&H30, Cpu.Pin)   ' SPI CS = P30
#End If
#If CQ_FRK_RX62N Then
        Private Shared [mod] As SPI.SPI_module = SPI.SPI_module.SPI1    ' SPI ch0 = SPI1
        Private Shared pinSDCS As Cpu.Pin = DirectCast(100, Cpu.Pin)    ' SPI CS = PC4 = 8*0xc + 4 = 100
#End If
#If CQ_FRK_NXP_ARM Then
        Private Shared [mod] As SPI.SPI_module = SPI.SPI_module.SPI1    ' SPI ch0 = SPI1
        Private Shared pinSDCS As Cpu.Pin = DirectCast(&H06, Cpu.Pin)   ' SPI CS = P0[6]
#End If
        Public Shared Sub Main()
            Dim i As Integer
            StorageDevice.MountSD("SD", Program.mod, Program.pinSDCS)
            Dim directories As String() = Directory.GetDirectories("\")
            Debug.Print(("directory count: " & directories.Length.ToString))
            For i = 0 To directories.Length - 1
                Debug.Print(("directory: " & directories(i)))
            Next i
            Dim files As String() = Directory.GetFiles(directories(0))
            Debug.Print(("file count: " & files.Length.ToString))
            For i = 0 To files.Length - 1
                Debug.Print(("filename: " & files(i)))
            Next i
        End Sub
    End Class
End Namespace