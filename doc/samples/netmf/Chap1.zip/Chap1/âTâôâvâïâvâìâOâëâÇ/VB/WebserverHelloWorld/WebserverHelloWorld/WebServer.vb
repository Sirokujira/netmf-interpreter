﻿#Const CQ_FRK_FM3 = True
'#Const CQ_FRK_RX62N = True
'#Const CQ_FRK_NXP_ARM = True

Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading
Imports Microsoft.VisualBasic.Constants

Namespace WebserverHelloWorld
    Public Class WebServer
        Implements IDisposable
#If CQ_FRK_FM3 Then
        Private Shared pinLED As Cpu.Pin = DirectCast(&HF3, Cpu.Pin)
#End If
#If CQ_FRK_RX62N Then
        Private Shared pinLED As Cpu.Pin = DirectCast(&HD, Cpu.Pin)
#End If
#If CQ_FRK_NXP_ARM Then
        Private Shared pinLED As Cpu.Pin = DirectCast(50, Cpu.Pin)
#End If
        Private led As OutputPort = New OutputPort(pinLED, False)
        Private server As Socket = Nothing
        ' Methods
        Public Sub New()
            Me.server = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
            Dim localEndPoint As New IPEndPoint(IPAddress.Any, 80)
            Me.server.Bind(localEndPoint)
            Me.server.Listen(5)
            Do While True
                Try 
                    Using clientSocket As Socket = Me.server.Accept
                        If ((Not clientSocket Is Nothing) AndAlso clientSocket.Poll(-1, SelectMode.SelectRead)) Then
                            Dim bytesReceived As Integer = clientSocket.Available
                            If (bytesReceived > 0) Then
                                Dim buffer As Byte() = New Byte(bytesReceived  - 1) {}
                                Dim byteCount As Integer = clientSocket.Receive(buffer, bytesReceived, SocketFlags.None)
                                Dim request As New String(Encoding.UTF8.GetChars(buffer))
                                Debug.Print(request)
                                Dim response As String = "Hello World"
                                Dim header As String = ("HTTP/1.0 200 OK" & vbCrLf & "Content-Type: text; charset=utf-8" & vbCrLf & "Content-Length: " & response.Length.ToString & vbCrLf & "Connection: close" & vbCrLf & vbCrLf)
                                clientSocket.Send(Encoding.UTF8.GetBytes(header), header.Length, SocketFlags.None)
                                clientSocket.Send(Encoding.UTF8.GetBytes(response), response.Length, SocketFlags.None)
                                Me.led.Write(True)
                                Thread.Sleep(150)
                                Me.led.Write(False)
                            End If
                        End If
                    End Using
                Catch e As Exception
                    Debug.Print(e.StackTrace)
                    Return
                End Try
            Loop
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            If (Not Me.server Is Nothing) Then
                Me.server.Close()
            End If
        End Sub

        Protected Overrides Sub Finalize()
            Try
                Me.Dispose()
            Finally
                MyBase.Finalize()
            End Try
        End Sub
    End Class
End Namespace

