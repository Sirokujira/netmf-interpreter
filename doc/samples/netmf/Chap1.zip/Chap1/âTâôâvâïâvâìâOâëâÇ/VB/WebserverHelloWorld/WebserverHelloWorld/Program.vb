﻿Imports Microsoft.SPOT
Imports Microsoft.SPOT.Net.NetworkInformation
Imports System
Imports System.Threading

Namespace WebserverHelloWorld
    Public Class Program
        ' Methods
        Public Shared Sub Main()
            Thread.Sleep(&HBB8)
            'NetworkInterface.GetAllNetworkInterfaces(0).EnableStaticIP("192.168.1.150", "255.255.255.0", "192.168.1.1")
            Debug.Print(("Web Server IP Address: " & NetworkInterface.GetAllNetworkInterfaces(0).IPAddress))
            Dim webServer As New WebServer
        End Sub

    End Class
End Namespace