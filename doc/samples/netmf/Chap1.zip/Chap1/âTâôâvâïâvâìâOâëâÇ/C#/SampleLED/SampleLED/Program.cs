﻿#define CQ_FRK_FM3
//#define CQ_FRK_RX62N
//#define CQ_FRK_NXP_ARM

using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SampleLED
{
    public class Program
    {
#if CQ_FRK_FM3
        static Cpu.Pin pinLED = (Cpu.Pin)0xF3;      // LED: PF3 pin
#endif
#if CQ_FRK_RX62N
        static Cpu.Pin pinLED = (Cpu.Pin)0x0D;      // LED: P15 pin (CN2-18) = 1*8+5 = 13
#endif
#if CQ_FRK_NXP_ARM
        static Cpu.Pin pinLED = (Cpu.Pin)50;        // LED: P1[18] pin = 1*32+18 = 50 
#endif
        public static void Main()
        {
            OutputPort GPIO_Out = new OutputPort(pinLED, true);
            Int32 i = 0;
            while (true)
            {
                Debug.Print("Hello, World! " + i.ToString() + " times");
                GPIO_Out.Write(false);
                Thread.Sleep(500);
                GPIO_Out.Write(true);
                Thread.Sleep(500);
                i++;
            }
        }
    }
}
