﻿#define CQ_FRK_FM3
//#define CQ_FRK_RX62N
//#define CQ_FRK_NXP_ARM

using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SampleAD
{
    public class Program
    {
#if CQ_FRK_FM3
        static Cpu.Pin LEDpin = (Cpu.Pin)0xF3;                      // PF3 - GPIO 0xF3: LED
        static Cpu.AnalogChannel acVR2 = (Cpu.AnalogChannel)16;     // PB0 - GPIO 0xB0: Analog 16
        static Cpu.AnalogChannel acThermal = (Cpu.AnalogChannel)17; // PB1 - GPIO 0xB1: Analog 17
#endif
#if CQ_FRK_RX62N
        static Cpu.Pin LEDpin = (Cpu.Pin)0x13;                      // P15 - GPIO 13: LED
        static Cpu.AnalogChannel acVR2 = (Cpu.AnalogChannel)0;      // PA0 - GPIO 80: Analog 0
        static Cpu.AnalogChannel acThermal = (Cpu.AnalogChannel)1;  // PA1 - GPIO 81: Analog 1  
#endif
#if CQ_FRK_NXP_ARM
        static Cpu.Pin LEDpin = (Cpu.Pin)0x32;                      // P1[18]-GPIO 50: LED
        static Cpu.AnalogChannel acVR2 = (Cpu.AnalogChannel)0;      // P0[23]-GPIO 23: Analog 0
        static Cpu.AnalogChannel acThermal = (Cpu.AnalogChannel)1;  // P0[24]-GPIO 24: Analog 1  
#endif

        public static void Main()
        {
            OutputPort LED = new OutputPort(LEDpin, false);
            AnalogInput aiVR2 = new AnalogInput(acVR2);
            AnalogInput aiThermal = new AnalogInput(acThermal);
            Int32 i = 0;
            while (true)
            {
                Debug.Print(i.ToString() + " times " +
                            "Slide Resistor = " + aiVR2.ReadRaw().ToString() +
                            " Thermal Sensor = " + aiThermal.ReadRaw().ToString());
                LED.Write(false);
                Thread.Sleep(500);
                LED.Write(true);
                Thread.Sleep(500);
                i++;
            }
        }

    }
}
