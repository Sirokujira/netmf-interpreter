﻿// For CQ_FRK_FM3
// COM1 - Serial Channel 0
// COM2 - Serial Channel 4
// COM3 - Serial Channel 3

#define CQ_FRK_FM3
//#define CQ_FRK_RX62N
//#define CQ_FRK_NXP_ARM

using System;
using System.IO.Ports;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SampleSerial
{
    public class Program
    {
#if CQ_FRK_FM3
        static Cpu.Pin pinLED = (Cpu.Pin)0xF3;      // LED: PF3 pin
#endif
#if CQ_FRK_RX62N
        static Cpu.Pin pinLED = (Cpu.Pin)0x0D;      // LED: P15 pin (CN2-18) = 1*8+5 = 13
#endif
#if CQ_FRK_NXP_ARM
        static Cpu.Pin pinLED = (Cpu.Pin)50;        // LED: P1[18] pin = 1*32+18 = 50 
#endif
        static private string PortName = Serial.COM1;
        static private OutputPort LEDPort;

        public static void Main()
        {
            Debug.Print("SampleSerial");
            Debug.Print("Please connect device COM1 to Host and press 1 and 0 keys?");
            Debug.Print("1: LED ON");
            Debug.Print("0: LED OFF");
            LEDPort = new OutputPort(pinLED, false);    // LED on
            SerialPort comx = new SerialPort(
                PortName,
                115200,
                Parity.None,
                8,
                StopBits.One
            );
            comx.DataReceived += new SerialDataReceivedEventHandler(Serial_DataReceived);
            comx.Open();
            while (true)
            {
            }
        }

        static void Serial_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort comx = (SerialPort)sender;
            byte[] key = new byte[1];
            int len = comx.Read(key, 0, key.Length);
            if (key[0] == '1')
            {
                LEDPort.Write(false);
            }
            else if (key[0] == '0')
            {
                LEDPort.Write(true);
            }
            comx.Write(key, 0, key.Length);
        }
    }
}
