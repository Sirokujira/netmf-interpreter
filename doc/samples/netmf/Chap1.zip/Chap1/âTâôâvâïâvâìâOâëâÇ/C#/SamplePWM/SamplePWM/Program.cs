﻿#define CQ_FRK_FM3
//#define CQ_FRK_RX62N
//#define CQ_FRK_NXP_ARM

using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SamplePWM
{
    public class Program
    {
#if CQ_FRK_FM3
        static Cpu.PWMChannel ch = Cpu.PWMChannel.PWM_6;    // LED PF3 -> channel 6
#endif
#if CQ_FRK_RX62N
        static Cpu.PWMChannel ch = Cpu.PWMChannel.PWM_0;    // LED P15 -> channel 0
#endif
#if CQ_FRK_NXP_ARM
        static Cpu.PWMChannel ch = Cpu.PWMChannel.PWM_0;    // LED P1[18] -> channel 0
#endif
        static double frequency = 100.0;
        static PWM pwm0 = new PWM((Cpu.PWMChannel)ch, frequency, 0.0, false);

        public static void pwm0Thread()
        {
            double duration = 0.0;
            double delta = 0.025;
            pwm0.Start();
            while (true)
            {
                Thread.Sleep(80);
                pwm0.DutyCycle = duration;
                duration += delta;
                if (duration >= 1.0)
                {
                    delta = -0.025;
                    duration = 0.975;
                }
                if (duration <= 0.0)
                {
                    delta = 0.025;
                    duration = 0.025;
                }
            }
        }

        public static void Main()
        {
            Thread thread0 = new Thread(pwm0Thread);
            thread0.Start();
            Int32 i = 0;
            while (true)
            {
                Debug.Print("Hello, World! " + i.ToString() + " times");
                Thread.Sleep(1000);
                i++;
            }
        }
    }
}
